
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 03/14/2023 10:40:49
-- Generated from EDMX file: D:\digital_imaging\digital_imaging\Models\DbModels.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [DigitalImage];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_doc_type_id]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[file_info] DROP CONSTRAINT [FK_doc_type_id];
GO
IF OBJECT_ID(N'[dbo].[FK_file_type_id]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[file_info] DROP CONSTRAINT [FK_file_type_id];
GO
IF OBJECT_ID(N'[dbo].[FK_uen_type_id]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[file_info] DROP CONSTRAINT [FK_uen_type_id];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[doc_type]', 'U') IS NOT NULL
    DROP TABLE [dbo].[doc_type];
GO
IF OBJECT_ID(N'[dbo].[file_info]', 'U') IS NOT NULL
    DROP TABLE [dbo].[file_info];
GO
IF OBJECT_ID(N'[dbo].[file_type]', 'U') IS NOT NULL
    DROP TABLE [dbo].[file_type];
GO
IF OBJECT_ID(N'[dbo].[uen_type]', 'U') IS NOT NULL
    DROP TABLE [dbo].[uen_type];
GO
IF OBJECT_ID(N'[dbo].[users]', 'U') IS NOT NULL
    DROP TABLE [dbo].[users];
GO
IF OBJECT_ID(N'[DigitalImageModelStoreContainer].[user_auditTrail]', 'U') IS NOT NULL
    DROP TABLE [DigitalImageModelStoreContainer].[user_auditTrail];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'doc_type'
CREATE TABLE [dbo].[doc_type] (
    [id] int IDENTITY(1,1) NOT NULL,
    [doc_type1] nvarchar(50)  NULL
);
GO

-- Creating table 'file_info'
CREATE TABLE [dbo].[file_info] (
    [id] int IDENTITY(1,1) NOT NULL,
    [pro_date] datetime  NULL,
    [run_num] nvarchar(50)  NULL,
    [file_type_id] int  NULL,
    [uen_type_id] int  NULL,
    [uen] nvarchar(50)  NULL,
    [doc_type_id] int  NULL,
    [created_at] datetime  NULL,
    [status] int  NULL,
    [maker] nvarchar(50)  NULL,
    [chacker] nvarchar(50)  NULL
);
GO

-- Creating table 'file_type'
CREATE TABLE [dbo].[file_type] (
    [id] int IDENTITY(1,1) NOT NULL,
    [file_type1] nvarchar(50)  NULL
);
GO

-- Creating table 'uen_type'
CREATE TABLE [dbo].[uen_type] (
    [id] int IDENTITY(1,1) NOT NULL,
    [uen_type1] nvarchar(50)  NULL
);
GO

-- Creating table 'users'
CREATE TABLE [dbo].[users] (
    [id] int IDENTITY(1,1) NOT NULL,
    [username] nvarchar(50)  NULL,
    [machine_name] nvarchar(50)  NULL
);
GO

-- Creating table 'user_auditTrail'
CREATE TABLE [dbo].[user_auditTrail] (
    [id] int IDENTITY(1,1) NOT NULL,
    [username] nvarchar(50)  NULL,
    [machine_name] nvarchar(50)  NULL,
    [message] nvarchar(50)  NULL,
    [date] datetime  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [id] in table 'doc_type'
ALTER TABLE [dbo].[doc_type]
ADD CONSTRAINT [PK_doc_type]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'file_info'
ALTER TABLE [dbo].[file_info]
ADD CONSTRAINT [PK_file_info]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'file_type'
ALTER TABLE [dbo].[file_type]
ADD CONSTRAINT [PK_file_type]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'uen_type'
ALTER TABLE [dbo].[uen_type]
ADD CONSTRAINT [PK_uen_type]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'users'
ALTER TABLE [dbo].[users]
ADD CONSTRAINT [PK_users]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [id] in table 'user_auditTrail'
ALTER TABLE [dbo].[user_auditTrail]
ADD CONSTRAINT [PK_user_auditTrail]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [doc_type_id] in table 'file_info'
ALTER TABLE [dbo].[file_info]
ADD CONSTRAINT [FK_doc_type_id]
    FOREIGN KEY ([doc_type_id])
    REFERENCES [dbo].[doc_type]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_doc_type_id'
CREATE INDEX [IX_FK_doc_type_id]
ON [dbo].[file_info]
    ([doc_type_id]);
GO

-- Creating foreign key on [file_type_id] in table 'file_info'
ALTER TABLE [dbo].[file_info]
ADD CONSTRAINT [FK_file_type_id]
    FOREIGN KEY ([file_type_id])
    REFERENCES [dbo].[file_type]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_file_type_id'
CREATE INDEX [IX_FK_file_type_id]
ON [dbo].[file_info]
    ([file_type_id]);
GO

-- Creating foreign key on [id] in table 'file_info'
ALTER TABLE [dbo].[file_info]
ADD CONSTRAINT [FK_uen_type_id]
    FOREIGN KEY ([id])
    REFERENCES [dbo].[uen_type]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------